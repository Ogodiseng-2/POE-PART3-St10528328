package chatmessagingapplication;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Part3FeaturesTest {
    @BeforeEach
    public void setUp() throws Exception {
        Message.resetForTests();
        Files.deleteIfExists(Path.of("messages.json"));
    }

    private void addPOEData() {
        new Message("+27834557896", "Did you get the cake?").processChoice(0);
        new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.").processChoice(2);
        new Message("+27834484567", "Yohoooo, I am at your gate.").processChoice(1);
        new Message("+27834557896", "It is dinner time !").processChoice(0);
        new Message("+27838884567", "Ok, I am leaving without you.").processChoice(2);
        Part3Features.populateArrays();
    }

    @Test
    public void arraysArePopulatedForSentDisregardedStoredHashesAndIds() {
        addPOEData();
        assertArrayEquals(new String[]{"Did you get the cake?", "It is dinner time !"}, Part3Features.getSentMessageArray());
        assertArrayEquals(new String[]{"Yohoooo, I am at your gate."}, Part3Features.getDisregardedMessageArray());
        assertEquals(2, Part3Features.getStoredMessageArray().length);
        assertEquals(5, Part3Features.getMessageHashArray().length);
        assertEquals(5, Part3Features.getMessageIDArray().length);
    }

    @Test
    public void longestMessageMatchesPOEExpectedStoredMessage() {
        addPOEData();
        assertEquals("Where are you? You are late! I have asked you to be on time.", Part3Features.getLongestSentMessage());
    }

    @Test
    public void searchByMessageIdReturnsRecipientAndMessage() {
        addPOEData();
        Message expected = Message.getSentMessages().get(0);
        assertEquals("Recipient: +27834557896\nMessage: Did you get the cake?", Part3Features.searchMessageByID(expected.getMessageID()));
        assertEquals("Message not found.", Part3Features.searchMessageByID("0000000000"));
    }

    @Test
    public void searchRecipientReturnsSentAndStoredMessages() {
        addPOEData();
        String result = Part3Features.searchMessagesByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void deleteByHashRemovesStoredMessageFromJson() {
        addPOEData();
        Message stored = Part3Features.loadStoredMessagesFromJSON().get(0);
        String result = Part3Features.deleteMessageByHash(stored.getMessageHash());
        assertTrue(result.contains("successfully deleted"));
        assertEquals(1, Part3Features.loadStoredMessagesFromJSON().size());
    }

    @Test
    public void reportListsHashRecipientAndMessageForSentMessages() {
        addPOEData();
        String report = Part3Features.displaySentMessageReport();
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient: +27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
    }
}
