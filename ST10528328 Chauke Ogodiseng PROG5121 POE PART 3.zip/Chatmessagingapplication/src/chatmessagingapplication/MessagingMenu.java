package chatmessagingapplication;

import javax.swing.JOptionPane;

public class MessagingMenu {

    public void runMenu() {

        JOptionPane.showMessageDialog(
                null,
                "Welcome to QuickChat."
        );

        while (true) {

            String choice = JOptionPane.showInputDialog(
                    null,
                    "QUICKCHAT MENU\n\n"
                    + "1. Send Messages\n"
                    + "2. Show recently sent messages\n"
                    + "3. Quit\n\n"
                    + "Enter your choice:"
            );

            // Stop if the user cancels
            if (choice == null) {
                break;
            }

            switch (choice.trim()) {

                case "1":
                    sendMessages();
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "View recent sent messages.");
                    int openReports = JOptionPane.showConfirmDialog(
                            null,
                            "Would you like to open the message reports?",
                            "QuickChat Reports",
                            JOptionPane.YES_NO_OPTION);
                    if (openReports == JOptionPane.YES_OPTION) showPart3Menu();
                    break;

                case "3":
                    JOptionPane.showMessageDialog(
                            null,
                            "Thank you for using QuickChat."
                    );
                    return;

                default:
                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid choice. Please enter 1, 2 or 3."
                    );
            }
        }
    }

    private void sendMessages() {

        String input = JOptionPane.showInputDialog(
                null,
                "How many messages would you like to send?"
        );

        if (input == null) {
            return;
        }

        int numberOfMessages;

        try {
            numberOfMessages = Integer.parseInt(input.trim());

            if (numberOfMessages <= 0) {
                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a number greater than zero."
                );
                return;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid whole number."
            );
            return;
        }

        for (int i = 0; i < numberOfMessages; i++) {

            String recipient = JOptionPane.showInputDialog(
                    null,
                    "Message " + (i + 1)
                    + " of " + numberOfMessages
                    + "\nEnter recipient number:"
            );

            if (recipient == null) {
                return;
            }

            String messageText = JOptionPane.showInputDialog(
                    null,
                    "Enter your message (maximum 250 characters):"
            );

            if (messageText == null) {
                return;
            }

            Message message = new Message(
                    recipient,
                    messageText
            );

            message.SentMessage();
        }

        JOptionPane.showMessageDialog(null,
                "Total messages sent: " + Message.returnTotalMessagess());
    }

    /** Opens the Part 3 reporting and message-management options. */
    private void showPart3Menu() {
        while (true) {
            Part3Features.populateArrays();
            String option = JOptionPane.showInputDialog(null,
                    "QUICKCHAT - MESSAGE REPORTS\n\n"
                    + "1. Display sender and recipient of sent messages\n"
                    + "2. Display longest message\n"
                    + "3. Search for a message ID\n"
                    + "4. Search messages by recipient\n"
                    + "5. Delete a message using its hash\n"
                    + "6. Display sent-message report\n"
                    + "7. Back to main menu");
            if (option == null || option.trim().equals("7")) return;
            String result;
            switch (option.trim()) {
                case "1":
                    result = Part3Features.displaySendersAndRecipients("Developer");
                    break;
                case "2":
                    result = Part3Features.getLongestSentMessage();
                    if (result.isEmpty()) result = "No messages available.";
                    break;
                case "3":
                    String id = JOptionPane.showInputDialog("Enter the message ID:");
                    if (id == null) continue;
                    result = Part3Features.searchMessageByID(id.trim());
                    break;
                case "4":
                    String recipient = JOptionPane.showInputDialog("Enter the recipient number:");
                    if (recipient == null) continue;
                    result = Part3Features.searchMessagesByRecipient(recipient.trim());
                    break;
                case "5":
                    String hash = JOptionPane.showInputDialog("Enter the message hash:");
                    if (hash == null) continue;
                    result = Part3Features.deleteMessageByHash(hash.trim());
                    break;
                case "6":
                    result = Part3Features.displaySentMessageReport();
                    break;
                default:
                    result = "Invalid option. Please choose 1 to 7.";
            }
            JOptionPane.showMessageDialog(null, result, "QuickChat", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}