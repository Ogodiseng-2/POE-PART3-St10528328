package chatmessagingapplication;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Part 3 reporting, parallel arrays and JSON restoration features. */
public class Part3Features {
    private static final Path JSON_FILE = Path.of("messages.json");
    private static String[] sentMessageArray = new String[0];
    private static String[] disregardedMessageArray = new String[0];
    private static String[] storedMessageArray = new String[0];
    private static String[] messageHashArray = new String[0];
    private static String[] messageIDArray = new String[0];

    private Part3Features() { }

    /** Refreshes the five required arrays from the application's message collections and JSON file. */
    public static void populateArrays() {
        List<Message> sent = Message.getSentMessages();
        List<Message> disregarded = Message.getDisregardedMessages();
        List<Message> stored = loadStoredMessagesFromJSON();
        sentMessageArray = texts(sent);
        disregardedMessageArray = texts(disregarded);
        storedMessageArray = texts(stored);
        List<Message> all = new ArrayList<>();
        all.addAll(sent); all.addAll(disregarded); all.addAll(stored);
        messageHashArray = new String[all.size()];
        messageIDArray = new String[all.size()];
        for (int i = 0; i < all.size(); i++) {
            messageHashArray[i] = all.get(i).getMessageHash();
            messageIDArray[i] = all.get(i).getMessageID();
        }
    }

    private static String[] texts(List<Message> messages) {
        String[] result = new String[messages.size()];
        for (int i = 0; i < messages.size(); i++) result[i] = messages.get(i).getMessageText();
        return result;
    }

    /** Reads stored messages written by Message.storeMessage() without an extra JSON dependency. */
    public static List<Message> loadStoredMessagesFromJSON() {
        List<Message> result = new ArrayList<>();
        if (!Files.exists(JSON_FILE)) return result;
        try {
            String json = Files.readString(JSON_FILE, StandardCharsets.UTF_8);
            Matcher objects = Pattern.compile("\\{([^{}]*)\\}").matcher(json);
            while (objects.find()) {
                String object = objects.group(1);
                String status = field(object, "status");
                if (!"Stored".equalsIgnoreCase(status)) continue;
                String id = field(object, "messageID");
                String number = field(object, "messageNumber");
                String recipient = field(object, "recipient");
                String message = field(object, "message");
                String hash = field(object, "messageHash");
                if (id != null && number != null && recipient != null && message != null && hash != null) {
                    result.add(new Message(id, Integer.parseInt(number), recipient, message, hash, "Stored"));
                }
            }
        } catch (IOException | NumberFormatException ex) {
            throw new IllegalStateException("Could not read stored messages from messages.json", ex);
        }
        return result;
    }

    private static String field(String object, String key) {
        Matcher matcher = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*(\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"|\\d+)").matcher(object);
        if (!matcher.find()) return null;
        if (matcher.group(2) == null) return matcher.group(1);
        return unescape(matcher.group(2));
    }

    private static String unescape(String value) {
        return value.replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t")
                .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    /** Displays sender and recipient for every sent message. */
    public static String displaySendersAndRecipients(String sender) {
        StringBuilder output = new StringBuilder();
        for (Message message : Message.getSentMessages()) {
            if (output.length() > 0) output.append("\n");
            output.append("Sender: ").append(sender)
                    .append(" | Recipient: ").append(message.getRecipient());
        }
        return output.toString();
    }

    /** Returns the longest message among the sent-message collection. */
    public static String getLongestSentMessage() {
        // The POE's supplied expected result is Stored Message 2, although
        // the feature description says "sent". Include sent and stored records
        // so the implementation matches the explicit test-data expectation.
        List<Message> messages = new ArrayList<>(Message.getSentMessages());
        messages.addAll(loadStoredMessagesFromJSON());
        Message longest = null;
        for (Message message : messages) {
            if (longest == null || message.getMessageText().length() > longest.getMessageText().length()) longest = message;
        }
        return longest == null ? "" : longest.getMessageText();
    }

    /** Looks up a sent message ID and returns its recipient and message. */
    public static String searchMessageByID(String id) {
        for (Message message : Message.getSentMessages()) {
            if (message.getMessageID().equals(id))
                return "Recipient: " + message.getRecipient() + "\nMessage: " + message.getMessageText();
        }
        return "Message not found.";
    }

    /** Returns all sent or stored messages for a recipient. */
    public static String searchMessagesByRecipient(String recipient) {
        StringBuilder output = new StringBuilder();
        for (Message message : Message.getSentMessages()) appendMatching(output, message, recipient);
        for (Message message : loadStoredMessagesFromJSON()) appendMatching(output, message, recipient);
        return output.length() == 0 ? "No messages found for this recipient." : output.toString();
    }

    private static void appendMatching(StringBuilder output, Message message, String recipient) {
        if (message.getRecipient().equals(recipient)) {
            if (output.length() > 0) output.append("\n");
            output.append(message.getMessageText());
        }
    }

    /** Deletes a matching message from memory and removes stored records from the JSON file. */
    public static String deleteMessageByHash(String hash) {
        Message match = null;
        for (Message m : Message.getSentMessages()) if (m.getMessageHash().equalsIgnoreCase(hash)) match = m;
        for (Message m : Message.getStoredMessages()) if (m.getMessageHash().equalsIgnoreCase(hash)) match = m;
        for (Message m : Message.getDisregardedMessages()) if (m.getMessageHash().equalsIgnoreCase(hash)) match = m;
        if (match == null) {
            for (Message m : loadStoredMessagesFromJSON()) if (m.getMessageHash().equalsIgnoreCase(hash)) match = m;
        }
        if (match == null) return "Message not found.";
        String deletedText = match.getMessageText();
        Message.removeMessageByHash(hash);
        try { removeFromJson(hash); } catch (IOException ex) {
            return "Message was removed from memory but JSON could not be updated.";
        }
        populateArrays();
        return "Message \"" + deletedText + "\" successfully deleted.";
    }

    private static void removeFromJson(String hash) throws IOException {
        if (!Files.exists(JSON_FILE)) return;
        String json = Files.readString(JSON_FILE, StandardCharsets.UTF_8);
        List<String> kept = new ArrayList<>();
        Matcher objects = Pattern.compile("\\{([^{}]*)\\}").matcher(json);
        while (objects.find()) {
            String object = objects.group(0);
            if (!hash.equalsIgnoreCase(field(objects.group(1), "messageHash"))) kept.add(object);
        }
        Files.writeString(JSON_FILE, "[" + String.join(",", kept) + "]", StandardCharsets.UTF_8);
    }

    /** Full sent-message report required by the POE. */
    public static String displaySentMessageReport() {
        StringBuilder report = new StringBuilder();
        for (Message message : Message.getSentMessages()) {
            report.append("Message Hash: ").append(message.getMessageHash())
                    .append("\nRecipient: ").append(message.getRecipient())
                    .append("\nMessage: ").append(message.getMessageText()).append("\n\n");
        }
        return report.length() == 0 ? "No sent messages available." : report.toString().trim();
    }

    public static String[] getSentMessageArray() { populateArrays(); return sentMessageArray.clone(); }
    public static String[] getDisregardedMessageArray() { populateArrays(); return disregardedMessageArray.clone(); }
    public static String[] getStoredMessageArray() { populateArrays(); return storedMessageArray.clone(); }
    public static String[] getMessageHashArray() { populateArrays(); return messageHashArray.clone(); }
    public static String[] getMessageIDArray() { populateArrays(); return messageIDArray.clone(); }

    /** Loads the official five POE records for repeatable automated tests/demo. */
    public static void loadPOETestData() {
        Message.resetForTests();
        new Message("+27834557896", "Did you get the cake?").processChoice(0);
        new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.").processChoice(2);
        new Message("+27834484567", "Yohoooo, I am at your gate.").processChoice(1);
        new Message("+27838884567", "It is dinner time !").processChoice(0);
        new Message("+27838884567", "Ok, I am leaving without you.").processChoice(2);
        populateArrays();
    }
}
